package com.example.przelicznik;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.textfield.TextInputEditText;

public class UnitsFragment extends Fragment {
    private TextInputEditText unitValueInput;
    private AutoCompleteTextView sourceUnit;
    private AutoCompleteTextView targetUnit;
    private Button convertButton;
    private TextView resultText;

    private static final String[] LENGTH_UNITS = {"mm", "cm", "inch", "m", "km", "yard"};
    private static final String[] AREA_UNITS = {"mm²", "cm²", "m²", "ar", "km²"};
    
    // Współczynniki konwersji do metrów (dla jednostek długości)
    private static final double[] LENGTH_RATES = {
        0.001,          // mm -> m
        0.01,           // cm -> m
        0.0254,         // inch -> m
        1.0,            // m -> m
        1000.0,         // km -> m
        0.9144          // yard -> m
    };
    
    // Współczynniki konwersji do metrów kwadratowych (dla jednostek powierzchni)
    private static final double[] AREA_RATES = {
        1000000.0,      // m² -> mm²
        10000.0,        // m² -> cm²
        1.0,            // m² -> m²
        0.01,           // m² -> ar
        0.000001        // m² -> km²
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_units, container, false);

        unitValueInput = view.findViewById(R.id.unitValueInput);
        sourceUnit = view.findViewById(R.id.sourceUnit);
        targetUnit = view.findViewById(R.id.targetUnit);
        convertButton = view.findViewById(R.id.convertUnitButton);
        resultText = view.findViewById(R.id.unitResultText);

        // Łączenie wszystkich jednostek w jedną listę
        String[] allUnits = new String[LENGTH_UNITS.length + AREA_UNITS.length];
        System.arraycopy(LENGTH_UNITS, 0, allUnits, 0, LENGTH_UNITS.length);
        System.arraycopy(AREA_UNITS, 0, allUnits, LENGTH_UNITS.length, AREA_UNITS.length);

        // Ustawienie adapterów dla rozwijanych list
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_dropdown_item_1line, allUnits);
        sourceUnit.setAdapter(adapter);
        targetUnit.setAdapter(adapter);

        convertButton.setOnClickListener(v -> convertUnit());

        return view;
    }

    private void convertUnit() {
        try {
            double value = Double.parseDouble(unitValueInput.getText().toString());
            String source = sourceUnit.getText().toString();
            String target = targetUnit.getText().toString();

            // Sprawdzenie czy jednostki są z tej samej kategorii (długość/powierzchnia)
            boolean sourceIsLength = isLengthUnit(source);
            boolean targetIsLength = isLengthUnit(target);
            
            if (sourceIsLength != targetIsLength) {
                Toast.makeText(getContext(), "Nie można przeliczać jednostek długości na powierzchnię i odwrotnie", 
                    Toast.LENGTH_SHORT).show();
                return;
            }

            double result;
            if (sourceIsLength) {
                result = convertLength(value, source, target);
            } else {
                result = convertArea(value, source, target);
            }

            // Formatowanie wyniku z odpowiednią liczbą miejsc po przecinku
            String format = sourceIsLength ? "%.3f" : "%.6f";
            resultText.setText(String.format("Wynik: " + format + " %s", result, target));
        } catch (NumberFormatException e) {
            Toast.makeText(getContext(), "Nieprawidłowy format wartości", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isLengthUnit(String unit) {
        for (String lengthUnit : LENGTH_UNITS) {
            if (lengthUnit.equals(unit)) return true;
        }
        return false;
    }

    private double convertLength(double value, String source, String target) {
        int sourceIndex = -1, targetIndex = -1;
        for (int i = 0; i < LENGTH_UNITS.length; i++) {
            if (LENGTH_UNITS[i].equals(source)) sourceIndex = i;
            if (LENGTH_UNITS[i].equals(target)) targetIndex = i;
        }
        
        // Konwersja przez metry jako jednostkę bazową
        double valueInMeters = value * LENGTH_RATES[sourceIndex];
        return valueInMeters / LENGTH_RATES[targetIndex];
    }

    private double convertArea(double value, String source, String target) {
        int sourceIndex = -1, targetIndex = -1;
        for (int i = 0; i < AREA_UNITS.length; i++) {
            if (AREA_UNITS[i].equals(source)) sourceIndex = i;
            if (AREA_UNITS[i].equals(target)) targetIndex = i;
        }
        
        // Konwersja przez metry kwadratowe jako jednostkę bazową
        double valueInSquareMeters = value / AREA_RATES[sourceIndex]; // Dzielimy przez współczynnik źródłowy
        return valueInSquareMeters * AREA_RATES[targetIndex]; // Mnożymy przez współczynnik docelowy
    }
} 