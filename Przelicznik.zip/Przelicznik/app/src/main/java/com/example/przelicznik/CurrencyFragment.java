package com.example.przelicznik;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.textfield.TextInputEditText;

public class CurrencyFragment extends Fragment {
    private TextInputEditText amountInput;
    private AutoCompleteTextView sourceCurrency;
    private AutoCompleteTextView targetCurrency;
    private Button convertButton;
    private TextView resultText;

    private static final String[] CURRENCIES = {"PLN(zł)", "USD($)", "EUR(€)", "GBP(£)"};
    private static final double[] RATES = {1.0, 0.25, 0.23, 0.20}; // Przykładowe kursy względem PLN

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_currency, container, false);

        amountInput = view.findViewById(R.id.amountInput);
        sourceCurrency = view.findViewById(R.id.sourceCurrency);
        targetCurrency = view.findViewById(R.id.targetCurrency);
        convertButton = view.findViewById(R.id.convertCurrencyButton);
        resultText = view.findViewById(R.id.currencyResultText);

        // Ustawienie adapterów dla rozwijanych list
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_dropdown_item_1line, CURRENCIES);
        sourceCurrency.setAdapter(adapter);
        targetCurrency.setAdapter(adapter);

        convertButton.setOnClickListener(v -> convertCurrency());

        return view;
    }

    private void convertCurrency() {
        try {
            double amount = Double.parseDouble(amountInput.getText().toString());
            String source = sourceCurrency.getText().toString();
            String target = targetCurrency.getText().toString();

            int sourceIndex = -1, targetIndex = -1;
            for (int i = 0; i < CURRENCIES.length; i++) {
                if (CURRENCIES[i].equals(source)) sourceIndex = i;
                if (CURRENCIES[i].equals(target)) targetIndex = i;
            }

            if (sourceIndex == -1 || targetIndex == -1) {
                Toast.makeText(getContext(), "Wybierz waluty", Toast.LENGTH_SHORT).show();
                return;
            }

            // Konwersja przez PLN jako walutę bazową
            double amountInPLN = amount / RATES[sourceIndex];
            double result = amountInPLN * RATES[targetIndex];

            resultText.setText(String.format("Wynik: %.2f %s", result, target));
        } catch (NumberFormatException e) {
            Toast.makeText(getContext(), "Nieprawidłowy format kwoty", Toast.LENGTH_SHORT).show();
        }
    }
} 