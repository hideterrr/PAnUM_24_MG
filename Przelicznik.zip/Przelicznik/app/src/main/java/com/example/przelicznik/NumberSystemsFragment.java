package com.example.przelicznik;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.textfield.TextInputEditText;

public class NumberSystemsFragment extends Fragment {
    private TextInputEditText inputValue;
    private AutoCompleteTextView sourceSystem;
    private AutoCompleteTextView targetSystem;
    private Button convertButton;
    private TextView resultText;

    private static final String[] SYSTEMS = {"dziesiętny", "dwójkowy", "czwórkowy", "szesnastkowy"};
    private static final int[] BASES = {10, 2, 4, 16};

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_number_systems, container, false);

        inputValue = view.findViewById(R.id.inputValue);
        sourceSystem = view.findViewById(R.id.sourceSystem);
        targetSystem = view.findViewById(R.id.targetSystem);
        convertButton = view.findViewById(R.id.convertButton);
        resultText = view.findViewById(R.id.resultText);

        // Ustawienie adapterów dla rozwijanych list
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_dropdown_item_1line, SYSTEMS);
        sourceSystem.setAdapter(adapter);
        targetSystem.setAdapter(adapter);

        convertButton.setOnClickListener(v -> convertNumber());

        return view;
    }

    private void convertNumber() {
        try {
            String value = inputValue.getText().toString();
            String sourceName = sourceSystem.getText().toString();
            String targetName = targetSystem.getText().toString();

            int sourceBase = -1, targetBase = -1;
            for (int i = 0; i < SYSTEMS.length; i++) {
                if (SYSTEMS[i].equals(sourceName)) sourceBase = BASES[i];
                if (SYSTEMS[i].equals(targetName)) targetBase = BASES[i];
            }

            if (sourceBase == -1 || targetBase == -1) {
                Toast.makeText(getContext(), "Wybierz systemy liczbowe", Toast.LENGTH_SHORT).show();
                return;
            }

            // Konwersja z systemu źródłowego na dziesiętny
            long decimal = Long.parseLong(value, sourceBase);
            // Konwersja z dziesiętnego na system docelowy
            String result = Long.toString(decimal, targetBase).toUpperCase();
            
            resultText.setText("Wynik: " + result);
        } catch (NumberFormatException e) {
            Toast.makeText(getContext(), "Nieprawidłowy format liczby", Toast.LENGTH_SHORT).show();
        }
    }
} 