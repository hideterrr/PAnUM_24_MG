package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {
    private TextInputEditText paceInput;
    private TextInputEditText speedInput;
    private TextInputEditText targetDistanceInput;
    private TextInputEditText targetTimeInput;
    private TextView resultsText;
    private Button calculateFromPaceButton;
    private Button calculateFromSpeedButton;
    private Button calculateTargetButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        initializeViews();
        setupClickListeners();
    }

    private void initializeViews() {
        paceInput = findViewById(R.id.paceInput);
        speedInput = findViewById(R.id.speedInput);
        targetDistanceInput = findViewById(R.id.targetDistanceInput);
        targetTimeInput = findViewById(R.id.targetTimeInput);
        resultsText = findViewById(R.id.resultsText);
        calculateFromPaceButton = findViewById(R.id.calculateFromPaceButton);
        calculateFromSpeedButton = findViewById(R.id.calculateFromSpeedButton);
        calculateTargetButton = findViewById(R.id.calculateTargetButton);
    }

    private void setupClickListeners() {
        calculateFromPaceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String paceStr = paceInput.getText().toString();
                if (!TextUtils.isEmpty(paceStr)) {
                    try {
                        float pace = Float.parseFloat(paceStr);
                        if (pace <= 0) {
                            showError("Tempo musi być większe od 0");
                            return;
                        }
                        calculateFromPace(pace);
                    } catch (NumberFormatException e) {
                        showError("Wprowadź prawidłowe tempo");
                    }
                } else {
                    showError("Wprowadź tempo biegu");
                }
            }
        });

        calculateFromSpeedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String speedStr = speedInput.getText().toString();
                if (!TextUtils.isEmpty(speedStr)) {
                    try {
                        float speed = Float.parseFloat(speedStr);
                        if (speed <= 0) {
                            showError("Prędkość musi być większa od 0");
                            return;
                        }
                        calculateFromSpeed(speed);
                    } catch (NumberFormatException e) {
                        showError("Wprowadź prawidłową prędkość");
                    }
                } else {
                    showError("Wprowadź prędkość");
                }
            }
        });

        calculateTargetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String distanceStr = targetDistanceInput.getText().toString();
                String timeStr = targetTimeInput.getText().toString();
                
                if (!TextUtils.isEmpty(distanceStr) && !TextUtils.isEmpty(timeStr)) {
                    try {
                        float distance = Float.parseFloat(distanceStr);
                        float time = Float.parseFloat(timeStr);
                        if (distance <= 0 || time <= 0) {
                            showError("Wartości muszą być większe od 0");
                            return;
                        }
                        calculateTarget(distance, time);
                    } catch (NumberFormatException e) {
                        showError("Wprowadź prawidłowe wartości");
                    }
                } else {
                    showError("Wypełnij wszystkie pola");
                }
            }
        });
    }

    private void calculateFromPace(float paceMinPerKm) {
        float speedKmH = 60f / paceMinPerKm;
        float marathonTimeMinutes = 42.195f * paceMinPerKm;
        float halfMarathonTimeMinutes = 21.0975f * paceMinPerKm;

        StringBuilder result = new StringBuilder();
        result.append(String.format("Prędkość: %.2f km/h\n\n", speedKmH));
        result.append("Czas maratonu (42.195 km): ").append(formatTime(marathonTimeMinutes)).append("\n");
        result.append("Czas półmaratonu (21.0975 km): ").append(formatTime(halfMarathonTimeMinutes)).append("\n");

        // Obliczenia dla własnego dystansu
        String customDistanceStr = targetDistanceInput.getText().toString();
        if (!TextUtils.isEmpty(customDistanceStr)) {
            try {
                float customDistance = Float.parseFloat(customDistanceStr);
                float customTimeMinutes = customDistance * paceMinPerKm;
                result.append(String.format("\nCzas dla %.2f km: %s", 
                    customDistance, formatTime(customTimeMinutes)));
            } catch (NumberFormatException ignored) {}
        }

        resultsText.setText(result.toString());
    }

    private void calculateFromSpeed(float speedKmH) {
        float paceMinPerKm = 60f / speedKmH;
        float marathonTimeMinutes = 42.195f * paceMinPerKm;
        float halfMarathonTimeMinutes = 21.0975f * paceMinPerKm;

        StringBuilder result = new StringBuilder();
        result.append(String.format("Tempo: %.2f min/km\n\n", paceMinPerKm));
        result.append("Czas maratonu (42.195 km): ").append(formatTime(marathonTimeMinutes)).append("\n");
        result.append("Czas półmaratonu (21.0975 km): ").append(formatTime(halfMarathonTimeMinutes)).append("\n");

        // Obliczenia dla własnego dystansu
        String customDistanceStr = targetDistanceInput.getText().toString();
        if (!TextUtils.isEmpty(customDistanceStr)) {
            try {
                float customDistance = Float.parseFloat(customDistanceStr);
                float customTimeMinutes = customDistance * paceMinPerKm;
                result.append(String.format("\nCzas dla %.2f km: %s", 
                    customDistance, formatTime(customTimeMinutes)));
            } catch (NumberFormatException ignored) {}
        }

        resultsText.setText(result.toString());
    }

    private void calculateTarget(float distance, float targetTimeMinutes) {
        float paceMinPerKm = targetTimeMinutes / distance;
        float speedKmH = 60f / paceMinPerKm;

        StringBuilder result = new StringBuilder();
        result.append(String.format("Dla dystansu %.2f km i czasu %s:\n\n", 
            distance, formatTime(targetTimeMinutes)));
        result.append(String.format("Wymagane tempo: %.2f min/km\n", paceMinPerKm));
        result.append(String.format("Wymagana prędkość: %.2f km/h", speedKmH));

        resultsText.setText(result.toString());
    }

    private String formatTime(float minutes) {
        int totalSeconds = Math.round(minutes * 60);
        int hours = totalSeconds / 3600;
        int mins = (totalSeconds % 3600) / 60;
        int secs = totalSeconds % 60;

        if (hours > 0) {
            return String.format("%d:%02d:%02d", hours, mins, secs);
        } else {
            return String.format("%02d:%02d", mins, secs);
        }
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
