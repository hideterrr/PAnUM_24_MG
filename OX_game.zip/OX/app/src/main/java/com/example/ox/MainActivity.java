package com.example.ox;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private String currentPlayer = "X";
    private double scoreX = 0;
    private double scoreO = 0;
    private Button[] buttons;
    private TextView scoreText;
    private String[] gameBoard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        scoreText = findViewById(R.id.scoreText);
        buttons = new Button[9];
        gameBoard = new String[9];

        //przeciwnicy i plansza
        for (int i = 0; i < 9; i++) {
            gameBoard[i] = "";
            String buttonID = "button" + i;
            int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
            buttons[i] = findViewById(resID);
            final int index = i;
            buttons[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (gameBoard[index].isEmpty()) {
                        makeMove(index);
                    }
                }
            });
        }
    }

    private void makeMove(int position) {
        gameBoard[position] = currentPlayer;
        buttons[position].setText(currentPlayer);
        
        // Set different colors for X and O
        if (currentPlayer.equals("X")) {
            buttons[position].setTextColor(getResources().getColor(R.color.player_x)); // Red color for X
        } else {
            buttons[position].setTextColor(getResources().getColor(R.color.player_o)); // Blue color for O
        }

        if (checkWin()) {
            if (currentPlayer.equals("X")) {
                scoreX++;
            } else {
                scoreO++;
            }
            updateScore();
            resetGame();
        } else if (isBoardFull()) {
            // Draw
            scoreX += 0.5;
            scoreO += 0.5;
            updateScore();
            resetGame();
        } else {
            currentPlayer = currentPlayer.equals("X") ? "O" : "X";
        }
    }

    private boolean checkWin() {
        int[][] winningCombinations = {
            {0, 1, 2}, {3, 4, 5}, {6, 7, 8}, //poziom
            {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, //pion
            {0, 4, 8}, {2, 4, 6}             //przekatna
        };

        for (int[] combination : winningCombinations) {
            if (!gameBoard[combination[0]].isEmpty() &&
                gameBoard[combination[0]].equals(gameBoard[combination[1]]) &&
                gameBoard[combination[1]].equals(gameBoard[combination[2]]))
            {
                return true;
            }
        }
        return false;
    }

    private boolean isBoardFull() {
        for (String cell : gameBoard) {
            if (cell.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    private void updateScore() {
        scoreText.setText("X = " + scoreX + " win | O = " + scoreO + " win");
    }

    private void resetGame() {
        for (int i = 0; i < 9; i++) {
            gameBoard[i] = "";
            buttons[i].setText("");
        }
        currentPlayer = "X";
    }
}
