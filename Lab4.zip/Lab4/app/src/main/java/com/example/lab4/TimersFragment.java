package com.example.lab4;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class TimersFragment extends Fragment {

    private CountDownTimer timer1, timer2;
    private boolean running1 = false, running2 = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_timers, container, false);

        TextView timer1TextView = view.findViewById(R.id.timer1);
        Button startTimer1 = view.findViewById(R.id.startTimer1);
        Button stopTimer1 = view.findViewById(R.id.stopTimer1);

        startTimer1.setOnClickListener(v -> {
            if (!running1) {
                running1 = true;
                timer1 = createTimer(60000, timer1TextView);
                timer1.start();
            }
        });

        stopTimer1.setOnClickListener(v -> {
            running1 = false;
            if (timer1 != null) timer1.cancel();
        });

        TextView timer2TextView = view.findViewById(R.id.timer2);
        Button startTimer2 = view.findViewById(R.id.startTimer2);
        Button stopTimer2 = view.findViewById(R.id.stopTimer2);

        startTimer2.setOnClickListener(v -> {
            if (!running2) {
                running2 = true;
                timer2 = createTimer(120000, timer2TextView);
                timer2.start();
            }
        });

        stopTimer2.setOnClickListener(v -> {
            running2 = false;
            if (timer2 != null) timer2.cancel();
        });

        return view;
    }

    private CountDownTimer createTimer(long duration, TextView textView) {
        return new CountDownTimer(duration, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                int seconds = (int) (millisUntilFinished / 1000) % 60;
                int minutes = (int) (millisUntilFinished / (1000 * 60));
                textView.setText(String.format("%02d:%02d", minutes, seconds));
            }

            @Override
            public void onFinish() {
                textView.setText("00:00");
            }
        };
    }
}
