package com.example.lab4;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class StopwatchesFragment extends Fragment {

    private Handler handler1 = new Handler();
    private Handler handler2 = new Handler();
    private long startTime1 = 0;
    private long startTime2 = 0;
    private boolean running1 = false;
    private boolean running2 = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_stopwatches, container, false);

        TextView stopwatch1 = view.findViewById(R.id.stopwatch1);
        Button startStopwatch1 = view.findViewById(R.id.startStopwatch1);
        Button stopStopwatch1 = view.findViewById(R.id.stopStopwatch1);

        startStopwatch1.setOnClickListener(v -> {
            if (!running1) {
                startTime1 = System.currentTimeMillis();
                running1 = true;
                handler1.post(updateStopwatch1(stopwatch1));
            }
        });

        stopStopwatch1.setOnClickListener(v -> {
            running1 = false;
            handler1.removeCallbacksAndMessages(null);
        });

        TextView stopwatch2 = view.findViewById(R.id.stopwatch2);
        Button startStopwatch2 = view.findViewById(R.id.startStopwatch2);
        Button stopStopwatch2 = view.findViewById(R.id.stopStopwatch2);

        startStopwatch2.setOnClickListener(v -> {
            if (!running2) {
                startTime2 = System.currentTimeMillis();
                running2 = true;
                handler2.post(updateStopwatch2(stopwatch2));
            }
        });

        stopStopwatch2.setOnClickListener(v -> {
            running2 = false;
            handler2.removeCallbacksAndMessages(null);
        });

        return view;
    }

    private Runnable updateStopwatch1(TextView stopwatch1) {
        return new Runnable() {
            @Override
            public void run() {
                long elapsedTime = System.currentTimeMillis() - startTime1;
                stopwatch1.setText(formatTime(elapsedTime));
                handler1.postDelayed(this, 10);
            }
        };
    }

    private Runnable updateStopwatch2(TextView stopwatch2) {
        return new Runnable() {
            @Override
            public void run() {
                long elapsedTime = System.currentTimeMillis() - startTime2;
                stopwatch2.setText(formatTime(elapsedTime));
                handler2.postDelayed(this, 10);
            }
        };
    }

    private String formatTime(long time) {
        int millis = (int) (time % 1000);
        int seconds = (int) (time / 1000) % 60;
        int minutes = (int) (time / (1000 * 60)) % 60;
        return String.format("%02d:%02d.%02d", minutes, seconds, millis / 10);
    }
}

