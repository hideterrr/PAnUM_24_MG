package com.example.app1;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    private boolean ArabicToRoman = true;

    public void onClickNumberButton(View view) {
        TextView textView = findViewById(R.id.ScreenArabic);
        TextView textView2 = findViewById(R.id.ScreenRoman);
        String text = textView.getText().toString();
        if (!ArabicToRoman) {
            textView.setText("");
            textView2.setText("");

            ArabicToRoman = true;
        }

        if (view.getId() == R.id.Button_1)
            text = text + "1";

        if (view.getId() == R.id.Button_2)
            text = text + "2";

        if (view.getId() == R.id.Button_3)
            text = text + "3";

        if (view.getId() == R.id.Button_4)
            text = text + "4";

        if (view.getId() == R.id.Button_5)
            text = text + "5";

        if (view.getId() == R.id.Button_6)
            text = text + "6";

        if (view.getId() == R.id.Button_7)
            text = text + "7";

        if (view.getId() == R.id.Button_8)
            text = text + "8";

        if (view.getId() == R.id.Button_9)
            text = text + "9";

        if (view.getId() == R.id.Button_0)
            text = text + "0";

        textView.setText(text);

        String convertedText = Converter.convertToRoman(text);
        textView2.setText(convertedText);
    }

    public void onClickNumeralButton(View view) {
        TextView textView = findViewById(R.id.ScreenArabic);
        TextView textView2 = findViewById(R.id.ScreenRoman);
        String text = textView2.getText().toString();

        if (ArabicToRoman) {
            textView.setText("");
            textView2.setText("");

            ArabicToRoman = false;
        }

        if (view.getId() == R.id.Button_M)
            text = text + "M";

        if (view.getId() == R.id.Button_L)
            text = text + "L";

        if (view.getId() == R.id.Button_C)
            text = text + "C";

        if (view.getId() == R.id.Button_D)
            text = text + "D";

        if (view.getId() == R.id.Button_I)
            text = text + "I";

        if (view.getId() == R.id.Button_V)
            text = text + "V";

        if (view.getId() == R.id.Button_X)
            text = text + "X";

        textView2.setText(text);

        String convertedText = Converter.convertToArabic(text);
        textView.setText(convertedText);
    }

    public void onClickClearButton(View view) {
        TextView textView = findViewById(R.id.ScreenArabic);
        TextView textView2 = findViewById(R.id.ScreenRoman);

        textView.setText("");
        textView2.setText("");
    }

    public void onClickBackButton(View view) {
        TextView textView = findViewById(R.id.ScreenArabic);
        TextView textView2 = findViewById(R.id.ScreenRoman);

        if (ArabicToRoman) {
            String text = textView.getText().toString();

            if (text.isEmpty())
                text = "";
            else
                text = text.substring(0, text.length() - 1);

            textView.setText(text);

            String convertedText = Converter.convertToRoman(text);
            textView2.setText(convertedText);
        } else {
            String text = textView2.getText().toString();

            if (text.isEmpty())
                text = "";
            else
                text = text.substring(0, text.length() - 1);

            textView2.setText(text);

            String convertedText = Converter.convertToArabic(text);
            textView.setText(convertedText);
        }
    }
}
